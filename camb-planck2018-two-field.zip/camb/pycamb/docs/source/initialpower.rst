camb.initialpower
==================================


.. autoclass:: camb.initialpower.InitialPowerParams
   :members:
   :inherited-members:




